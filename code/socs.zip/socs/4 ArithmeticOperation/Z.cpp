#include<stdio.h>
int main()
{
	double t,a, b, c, d;
	int i=1;
	scanf("%d",&t);
	while(i<=3){
		scanf("%lf %lf %lf %lf", &a, &b, &c, &d);
		printf("%.2lf\n", a/1+b/2+b/2+c/3+d/4+c/3+c/3+d/4+c/3+b/2+b/2+a/1);
	i++;
	}
	return 0;
}
