#include<stdio.h>
#include<string.h>
#include<stdlib.h>
int main(){
	int t, m;
	char from, to;
	char kata[1001];
	scanf("%d", &t);
	for(int i=1;i<=t;i++){
		scanf("%s", kata); getchar();
		scanf("%d", &m);
		for(int j=0;j<m;j++){
			scanf("%c %c", &from, &to); fflush(stdin);
			for(int j=0;j<strlen(kata);j++){
				if(kata[j]==from){
					kata[j]=to;
				}
			}			
		}
	printf("Case #%d: %s\n", i, kata);
	}
	return 0;
}
